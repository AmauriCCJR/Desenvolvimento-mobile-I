import 'package:aula02_estrutura_de_dados/tela_inicial.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: tela_inicial()
  ));
}
