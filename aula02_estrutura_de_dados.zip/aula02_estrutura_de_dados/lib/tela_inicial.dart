import 'package:flutter/material.dart';

class tela_inicial extends StatefulWidget {
  const tela_inicial({super.key});

  @override
  State<tela_inicial> createState() => _tela_inicialState();
}

class _tela_inicialState extends State<tela_inicial> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(195, 0, 0, 0),
      appBar: AppBar(
        actions: [
          Builder(
            builder: (context) => IconButton(
              onPressed: () {
                Scaffold.of(context).openEndDrawer();
              },
              icon: Icon(Icons.settings),
            ),
          ),
        ],
        title: Text("Estrutura do Scaffold"),
        backgroundColor: const Color.fromARGB(215, 27, 39, 255),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Text("Body"),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(
                8,
                (_) => Container(
                  width: 64,
                  height: 64,
                  margin: EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade100,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),

      drawer: Drawer(
        backgroundColor: Colors.blue,
        child: Column(
          children: [
            SizedBox(height: 20),
            Text(
              "Drawer (Esquerda)",
              style: TextStyle(color: Colors.white, fontSize: 34),
            ),
            SizedBox(height: 20),
            SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Column(
              children: List.generate(
                8,
                (_) => Container(
                  width: 64,
                  height: 64,
                  margin: EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade100,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
            SizedBox(height: 40),
          ],
        ),
      ),

      endDrawer: Drawer(backgroundColor: Colors.deepPurple, child: Container()),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home_filled), label: 'home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'configuracoes',
          ),
        ],
      ),
      bottomSheet: Container(height: 40, child: Text("Rodapé")),
      //floatingActionButton: FloatingActionButton(onPressed: (){}),
    );
  }
}
